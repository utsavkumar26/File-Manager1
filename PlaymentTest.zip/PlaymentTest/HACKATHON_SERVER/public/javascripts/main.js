function searchKey(obj, key) {
	if(obj === null || obj === undefined) 
		return undefined;
	else {
		for(k in obj) {
			if(k === key) {
				return obj[k];
			} else if(obj.hasOwnProperty(k)){
				currentKey = k;
				 var temp = searchKey(obj[k], key);
				 if(temp !== undefined)
				 	return temp;
				 else
				 	continue;
			}
		}
	}
}
var currentKey = "root";
function findParent(obj, key) {
	if(obj === null || obj === undefined) 
		return undefined;
	else {
		for(k in obj) {
			if(k === key) {
				return obj;
			} else if(obj.hasOwnProperty(k)){
				currentKey = k;
				 var temp = findParent(obj[k], key);
				 if(temp !== undefined)
				 	return temp;
				 else
				 	continue;
			}
		}
	}
}
angular.module('FolderApp', [])
      .controller('FolderAppController', function($scope) {
      	  $scope.currentFolder = "root";
      	  $scope.showAddFolder = false;
      	  $scope.folderStructure = {"root": {
      	  										
      	  									}
      	  							};
      	  $scope.folders=[
      	  			];
      	  $scope.showInputField = function() {
      	  	if(!$scope.showAddFolder){
      	  		$scope.showAddFolder = true;
      	  	}
      	  }
          $scope.goBack = function (currentFolder) {
          	  var parent = findParent($scope.folderStructure, currentFolder);
          	  if(parent === undefined) {
          	  	parent = $scope.folderStructure;
          	  }
          	  var foldersInCurrentFolder = [];
          	  for(var key in parent) {
          	  	foldersInCurrentFolder.push({"name": key.toString()});
          	  };
          	  $scope.folders = foldersInCurrentFolder;
          	  $scope.currentFolder = currentKey;
          };
          $scope.createNewFolder = function (currentFolder, folderName) {
              var folderStructure = $scope.folderStructure;
              var currentFolderElements = searchKey($scope.folderStructure, currentFolder);
              var parent = findParent($scope.folderStructure, currentFolder);

              currentFolderElements[folderName] = {};
              parent[currentFolder] = currentFolderElements;
              $scope.folders.push({name:folderName});
              $scope.showAddFolder = false;

          };
          $scope.goInTo = function (folderName) {
              var currentFolder = searchKey($scope.folderStructure, folderName);
               var foldersInCurrentFolder = [];
              for(var key in currentFolder) {
          	  	foldersInCurrentFolder.push({"name": key.toString()});
          	  };
          	  $scope.folders = foldersInCurrentFolder;
          	  $scope.currentFolder = folderName;
          };
      });

/*
function TodoCtrl($scope) {
  
  $scope.todos = [
    {text:'Use Angular 1.X', done:false},         
    {text: 'Build an app', done:false}
  ];
  
  $scope.getTotalTodos = function () {
    return $scope.todos.length;
  };
  
  
  $scope.addTodo = function () {
    $scope.todos.push({text:$scope.formTodoText, done:false});   //explain about two way binding using ng-model
    $scope.formTodoText = '';
  };
  
    $scope.createNewFolder = function () {
            var pending = $scope.todos;
            $scope.todos = [];
            angular.forEach(pending, function(todo) {
            if (!todo.done) 
              return $scope.todos.push(todo);
        });
        
    };
}*/