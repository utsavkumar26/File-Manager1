var express = require('express');
var path    = require("path");
var router = express.Router();
var fs = require('fs');
var regression = require('regression');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.sendFile(path.join(process.env.USER_KEY + '/HACKATHON_SERVER/views/index.html'));
});

module.exports = router;
